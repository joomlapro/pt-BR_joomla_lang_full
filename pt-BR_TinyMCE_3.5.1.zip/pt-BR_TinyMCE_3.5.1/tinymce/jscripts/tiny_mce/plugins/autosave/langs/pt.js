tinyMCE.addI18n('pt.autosave',{
restore_content: "Restaurar conteúdo salvo automáticament",
warning_message: ""Se você restaurar o conteúdo gravado, você vai perder todo o conteúdo que está atualmente no editor.\n\nVocê tem certeza de que deseja restaurar o conteúdo salvo?"
});